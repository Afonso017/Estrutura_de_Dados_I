package lista1;

public class Q01 {
    
    public static void main(String[] args) {
        int idade = 21;
        double altura = 1.56;
        String nome = "Afonso Sim�o de G�is Neto";
        char primeiraLetra = nome.charAt(0);
        
        System.out.println("Nome: " + nome + "\n"
				+ "Idade: " + idade + "\n"
				+ "Altura: " + altura + "m\n"
				+ "Primeira letra do nome: " + primeiraLetra);
    }
}
